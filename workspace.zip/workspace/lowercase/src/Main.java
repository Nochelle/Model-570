import java.util.Scanner;

public class Main
{
    public static void main(String args[])
    {
        Scanner ob=new Scanner(System.in);
       
        String s=ob.nextLine();
        UserMainCode ur=new UserMainCode();
       
        System.out.println(ur.processString(s));
    }
} 