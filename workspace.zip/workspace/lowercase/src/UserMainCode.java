public class UserMainCode{
	int xCounter = 0;
    int writeIndex = 0;
  
   
	public String processString(String s) {
		
		// TODO Auto-generated method stub
		  final int size = s.length();
		    char[] resultArray = new char[size];
		    for (int readIndex = 0; readIndex < size; readIndex++) {
		        char c = s.charAt(readIndex);
		        if(c == 'x'){
		          
					xCounter++;
		            resultArray[size - xCounter] = c;
		        } else {
		            resultArray[writeIndex++] = c;
		        }
		    }
		    return new String(resultArray);
	}

}