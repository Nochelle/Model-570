import java.util.*;
import java.lang.*;
public class Main {
static String a;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String original = sc.nextLine();
UserMainCode u=new UserMainCode();
System.out.println(u.reverseString(original));
	}

}
