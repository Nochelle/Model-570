import java.util.*;
public class UserMainCode {

	static String original,reverse="";

	static StringBuilder reverseString(String original)
	{
		StringBuilder s1=new StringBuilder(original);
		s1.reverse();
		return s1;
	}

}

	