import java.util.HashMap;
public class UserMainCode {
	static HashMap<Integer, Integer> findPass(HashMap<Integer, Integer> hmap) {
		HashMap<Integer,Integer> values = new HashMap<>();
		for(Integer key:hmap.keySet()) {
			if(hmap.get(key) > 75)
				values.put(key, hmap.get(key));
		}
		return values;		
	}
}

