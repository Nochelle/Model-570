import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;


public class Main {
	public static void main(String args[]) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		HashMap<Integer,Integer> hmap = new HashMap<>();
		int size = Integer.parseInt(br.readLine());
		for(int i=0; i<2*size; i++) {
			hmap.put(Integer.parseInt(br.readLine()), Integer.parseInt(br.readLine()));
			i++;
		}
		UserMainCode userMainCode = new UserMainCode();
		HashMap<Integer,Integer> values = userMainCode.findPass(hmap);
		for(int key:values.keySet()) {
			System.out.println(key);
		}
	}
}




