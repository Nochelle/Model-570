
public class Sample extends Thread {
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Task 1 running");
		}
		notify();
	}
	public static void main(String[] args)throws Exception {
		Sample a=new Sample();
		System.out.println(a.getState());
		a.start();
		a.setPriority(NORM_PRIORITY);
		System.out.println(a.getPriority());
		a.setPriority(MIN_PRIORITY);
		System.out.println(a.getPriority());
	}

}
