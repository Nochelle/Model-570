package threads;

public class Parent implements Runnable{
	
		public void run()
		{
			for(int i=0;i<5;i++)
			{
				System.out.println("Task 1 running");
			}
			notify();
		}
		public static void main(String[] args, Object MIN_PRIORITY)throws Exception {
			Parent a=new Parent();
			Thread t=new Thread(a);
			System.out.println(t.getState());
			t.start();
			t.setPriority((int)MIN_PRIORITY);
			System.out.println(t.getPriority());
			t.setPriority((int) MIN_PRIORITY);
			System.out.println(t.getPriority());
		}
		
	}


