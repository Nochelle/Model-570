import java.util.HashMap;
import java.util.Iterator;

public class UserMainCode {
    static int k,sum=0;
    static int getSumOfEven(HashMap<Integer, Integer> hmap) {
      Iterator it=hmap.keySet().iterator();
     while(it.hasNext())
     {
    	 k=(int) it.next();
    	 if(k%2==0)
    	 {
    		 sum=sum+hmap.get(k);
    	 }
    	 
     }
	return sum;
    }
    
}
