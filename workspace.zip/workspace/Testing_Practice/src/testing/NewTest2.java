package testing;

import org.testng.annotations.Test;

public class NewTest2 {
	@Test
public void driver()
{
	System.out.println("Hey");
}
}
