package testing;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest3 {
	@Test
	public void run()
	{
		SoftAssert sa=new SoftAssert();
		sa.assertTrue(2>1);
		System.out.println("assertion passed");
		sa.assertTrue(1>2);
		System.out.println("assertion failed");
		sa.assertEquals("Sample","Failed");
		
	}
	

}
