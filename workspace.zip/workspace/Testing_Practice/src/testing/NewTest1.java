package testing;

import org.testng.annotations.Test;

public class NewTest1 {
	@Test
	public void stub()
	{
		System.out.println("Ho");
	}

}
