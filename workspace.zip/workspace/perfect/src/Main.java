import java.util.*;  
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n;
Scanner sc=new Scanner(System.in);
n=sc.nextInt();
UserMainCode m=new UserMainCode();
Boolean c=m.isPerfect(n);

if(c)
{
	System.out.println("Perfect number");
}
else
{
	System.out.println("Not a perfect number");
}
	}

}  

	
	


