public class UserMainCode {
	static Boolean isPerfect(int a)
	{
		Boolean b=false;
		int sum=0;
		for(int i=1;i<=a/2;i++)
		{
			if(a%i==0)
			{
				sum=sum+i;
			}
		}
		if(sum==a)
		{
			b=true;
		}
		return b;
	}
}  