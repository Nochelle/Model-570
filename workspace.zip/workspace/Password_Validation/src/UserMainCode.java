
public class UserMainCode {

	static void validatePassword(String str1,String str2)
	{
		str1.toCharArray();

		String d ="";
		for(int i=0;i<str1.length();i++)
		{
			if(i%2!=0)
			{
				if(!(str1.charAt(i)=='a'||str1.charAt(i)=='e'||str1.charAt(i)=='i'||str1.charAt(i)=='o'||str1.charAt(i)=='u'||str1.charAt(i)=='A'||str1.charAt(i)=='E'||str1.charAt(i)=='I'||str1.charAt(i)=='O'||str1.charAt(i)=='U'))
				{
					d=d+str1.charAt(i);
				}
			}
			else 
			{
				d=d+str1.charAt(i);
			}
		}

		if(d.equals(str2))
		{
			System.out.println("Valid");
		}
		else
		{
			System.out.println("Invalid");
		}


	}
}
