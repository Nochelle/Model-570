import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    private static int count;
    
    public static void main(String args[])throws IOException
    
    {
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
 String str1= br.readLine();
 String str2=br.readLine();
 UserMainCode u=new UserMainCode();
 u.validatePassword(str1, str2);

 
    }
}
