import java.util.*;
public class Main {
		static String fname;
		static String lname;
		static String contactNumber;
		static String email;
		static String proofType;
		static String proofId;
		static String res;
		static String updateEmail;
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Registration:\n");
		System.out.println("Enter the customer details:");
		System.out.println("Enter the first name:");
		fname=sc.nextLine();
		System.out.println("Enter the last name:");
		lname=sc.nextLine();
		System.out.println("Enter the contact number:");
		contactNumber=sc.nextLine();
		System.out.println("Enter the e-mail id:");
		email=sc.nextLine();
		System.out.println("Enter the proof type:");
		proofType=sc.nextLine();
		System.out.println("Enter the proof id:");
		proofId=sc.nextLine();
		System.out.println("Thank you for registering. Your id is 1..");
		
		Customer c=new Customer();
		c.registerCustomer(fname,lname,contactNumber,email,proofType,proofId);
		c.display();
		
		System.out.println("Do you want to update email?(y/n)");
		res=sc.nextLine();
		if(res.equals("y"))
		{
			System.out.println("Enter the new email:");
			email=sc.nextLine();
			c.UpdateEmail(email);
			c.display();
		
		}
		System.out.println("Thank You");
			
	}
	} 