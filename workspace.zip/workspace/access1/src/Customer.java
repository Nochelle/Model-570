
public class Customer {
	String fName,lName, contactNumber, eMail, proofType, proofId;
 public void registerCustomer(String fname,String lname,String contactNumber,String email, String proofType, String proofId){
		        	 this.fName=fname;
		        	 this.lName=lname;
		        	 this.contactNumber=contactNumber;
		        	 this.eMail=email;
		        	 this.proofType=proofType;
		        	 this.proofId=proofId;     			 
			}
		         public void display()
		         {
		        	 System.out.println("The customer details are as follows");
		        	 System.out.println("The customer details are:");
		        	 System.out.println("First Name : "+this.fName);
		        	 System.out.println("Last Name : "+this.lName);
		        	 System.out.println("COntact Number : "+this.contactNumber);
		        	 System.out.println("E-Mail : "+this.eMail);
		        	 System.out.println("Proof Type : "+this.proofType);
		        	 System.out.println("Proof ID : "+this.proofId);
		        	 
		         }
		         public void UpdateEmail(String mail)
		         {
		        	 this.eMail=mail;
		        	 System.out.println("Email updated.");
		         }

		}  


