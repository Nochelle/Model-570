 import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int d,e,f;
		Scanner sc=new Scanner(System.in);
		d=sc.nextInt();
		e=sc.nextInt();
		f=sc.nextInt();
		UserMainCode u=new UserMainCode();
		
	System.out.println(u.findMax(d, e, f)+ " is the maximum number");
     

	}

}
