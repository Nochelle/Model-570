import java.util.ArrayList;
import java.util.Iterator;

public class UserMainCode {
	
	static int r,count=0;
	
	public static ArrayList<Integer> findDifference(ArrayList<Integer> a, ArrayList<Integer> b) {
		ArrayList<Integer> c=new ArrayList<Integer>();
	for(int i=0;i<a.size();i++)
		{
			for(int j=0;j<b.size();j++)
			{
				if(a.get(i)==b.get(j))
				{
					r=a.get(i);
				count++;
				}
				
			}
			if(count==0)
			{
				c.add(a.get(i));
				
			}
			count=0;
		}
	    return c;
	}
}
