import java.util.*;
import java.io.*;
public class Main {

	
		String name;
		String address;
		String contactNumber; 
		String email; 
		String proofType; 
		String proofID;
	

	public static void main(String[] args)throws Exception {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Registration\n");
		System.out.println("Enter your name");
		String name= br.readLine();
		System.out.println("Enter your address");
		String address= br.readLine();
		System.out.println("Contact Number");
		String contactNumber=br.readLine();
		System.out.println("E-Mail ID");
		String email= br.readLine();
		System.out.println("Enter proof type");
		String proofType= br.readLine();
		System.out.println("Enter proof id");
		String proofID= br.readLine();
		Main a=new Main();
		
		a.register(name,address,contactNumber,email,proofType,proofID);
		
	}

	public static void register(String name,
	String address,
	String contactNumber,
	String email, 
	String proofType,
	String proofID) {
		System.out.println("\nWelcome " +name+".");
		System.out.println("Here are your details");
		System.out.println("Address: " +address);
		System.out.println("Contact Number: "+contactNumber);
		System.out.println("E-Mail ID: "+email);
		System.out.println("Proof type: "+proofType);
		System.out.println("Proof id: "+proofID);
		System.out.println("\nThank you for registering. Your id is 1..");
	}

}
