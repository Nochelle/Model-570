import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		HashMap<Integer,String> stuClassMap=new HashMap<>();
		HashMap<Integer,Integer> stuMarkMap=new HashMap<>();
		for(int i=0;i<a;i++)
		{
			int b=sc.nextInt();
			String c=sc.next();
			int d=sc.nextInt();
			stuClassMap.put(b, c);
			stuMarkMap.put(b,d);
		}
		UserMainCode u=new UserMainCode();
		HashMap<Integer,Integer> stuIncMap=u.increaseMarks(stuClassMap, stuMarkMap);
		for(Map.Entry<Integer, Integer> key:stuIncMap.entrySet())
		{
			System.out.println(key.getKey()+" "+ key.getValue());
		}
	}
}


