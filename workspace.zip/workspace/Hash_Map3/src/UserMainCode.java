import java.util.HashMap;
import java.util.Map;

public class UserMainCode {

	public static HashMap<Integer, Integer> increaseMarks(HashMap<Integer, String> stuClassMap, HashMap<Integer, Integer> stuMarkMap) {
		HashMap<Integer,Integer> stuIncMap=new HashMap<>();
		for(Integer key:stuClassMap.keySet())
		{
			if(stuClassMap.get(key).equals("BE-CSE"))
			{
				stuIncMap.put(key,stuMarkMap.get(key)+5);
			}
		}
		return stuIncMap; 
	}

}


