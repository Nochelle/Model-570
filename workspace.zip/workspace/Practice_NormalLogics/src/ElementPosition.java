import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ElementPosition {
	static void getElementPosition(int a,String b[],String c)
	{
		ArrayList<String> ar=new ArrayList<String>();
		for(int i=0;i<b.length;i++)
		{
			ar.add(b[i]);
		}
		Collections.sort(ar);
		Collections.reverse(ar);
		for(int i=0;i<a;i++)
		{
			if(c.equals(ar.get(i)))
			{
				System.out.println(i+1);
			}
		}
		
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	String b[]=new String[a];
	for(int i=0;i<b.length;i++)
	{
		b[i]=sc.next();
	}
	String c=sc.next();
	ElementPosition.getElementPosition(a, b,c);
}
}
