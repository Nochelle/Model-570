import java.util.Scanner;

public class Reversing_Number {
	public static void main(String[] args) {
		int b = 0;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		while(a!=0)
		{
			 b=a%10;
			System.out.print(b);
			a=a/10;
		}
	
	}

}
