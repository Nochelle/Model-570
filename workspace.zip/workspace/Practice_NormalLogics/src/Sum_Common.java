import java.util.Scanner;

public class Sum_Common {
	static void getSumOfIntersection(int a,int b[],int c[])
	{
		int result=0,count=0,res1=0,res2=0;
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<c.length;j++)
			{
				if(b[i]==c[j])
				{
					result=result+b[i];
					count=1;
				}
			
			}
			}
		if(count==0)
		{
			System.out.println("No Common Elements");
		}
		else
		{
			System.out.println(result);
		}
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int d=sc.nextInt();
	int b[]=new int[a];
	int c[]=new int[d];
	for(int i=0;i<a;i++)
	{
		b[i]=sc.nextInt();
	}
	for(int i=0;i<d;i++)
	{
		c[i]=sc.nextInt();
	}
	Sum_Common.getSumOfIntersection(a, b, c);
}
}
