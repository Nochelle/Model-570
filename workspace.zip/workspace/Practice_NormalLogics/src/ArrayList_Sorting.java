import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class ArrayList_Sorting {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	ArrayList<Integer> a=new ArrayList<Integer>();
	for(int i=0;i<5;i++)
	{
		a.add(sc.nextInt());
	}
	ArrayList<Integer> b=new ArrayList<Integer>();
	for(int i=0;i<5;i++)
	{
		b.add(sc.nextInt());
	}
	ArrayList<Integer> c=new ArrayList<Integer>();
		c.addAll(a);
		c.addAll(b);
	Collections.sort(c);
	ArrayList<Integer> d=new ArrayList<Integer>();
		d.add(c.get(2));
		d.add(c.get(6));
		d.add(c.get(8));
	Iterator it=d.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
}
}
