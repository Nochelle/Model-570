import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class DifferenceOfElements {
	static void getBigDiff(int a,int b[])
	{
		int diff=0;
		Arrays.sort(b);
		diff=b[a-1]-b[0];
		System.out.println(diff);
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b[]=new int[a];
	for(int i=0;i<a;i++)
	{
		b[i]=sc.nextInt();
	}
	DifferenceOfElements.getBigDiff(a, b);
}
}
