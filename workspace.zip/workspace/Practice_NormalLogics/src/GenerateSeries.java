import java.util.Scanner;

public class GenerateSeries {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b[]=new int[a];
	int j=0;
	for(int i=1;i<=a;i++)
	{
		b[j]=i;
		j++;
	}
	int sum=b[0];
	for(int i=1;i<b.length;i++)
	{
		if(i%2!=0)
		{
			sum=sum+b[i];
		}
		else
		{
			sum=sum-b[i];
		}
	}
	System.out.println(sum);
}
}
