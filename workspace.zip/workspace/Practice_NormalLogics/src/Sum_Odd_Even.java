import java.util.Scanner;

public class Sum_Odd_Even {
public static void main(String[] args) {
	int sum=0;
	int flag=0;
	Scanner sc=new Scanner(System.in);
	String a=sc.next();
	a.toCharArray();
	for(int i=0;i<a.length();i++)
	{
	//int b=a.charAt(i);
	if(i%2!=0)
	{
		sum=sum+a.charAt(i);
		flag=1;
	}
	}
	if(sum%2==0)
	{
		System.out.println("Sum of the odd digits is even");
	}
	else
	{
		System.out.println("Sum of the odd digits is odd");
	}
	
}
}
