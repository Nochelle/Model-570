import java.util.Scanner;

public class Sum_Squares {
public static void main(String[] args) {
	int sum=0;
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	while(a!=0)
	{
		int b=a%10;
		if(b%2==0)
		{
			sum=sum+(b*b);
		}
		a=a/10;
	}
	System.out.println(sum);
}	

}
