import java.util.Scanner;

public class Ncr_Program {
	static int calculateNcr(int a,int b)
	{
		int factn=1,factr=1,factnr=1;
		for(int i=1;i<=a;i++)
		{
			factn=factn*i;
		}
		for(int i=1;i<=b;i++)
		{
			factr=factr*i;
		}
		for(int i=1;i<=(a-b);i++)
		{
			factnr=factnr*i;
		}
		int result=factn/(factr*factnr);
		return result;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b=sc.nextInt();
	System.out.println(Ncr_Program.calculateNcr(a, b));
}
}
