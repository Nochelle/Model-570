import java.util.Scanner;

public class Sum_Power {
	static int getSumofPower(int a,int b[])
	{
		int sum=0;
		for(int i=0;i<a;i++)
		{
			sum=(int) (sum+Math.pow(b[i], i));
		}
		return sum;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b[]=new int[a];
	for(int i=0;i<a;i++)
	{
		b[i]=sc.nextInt();
	}
	System.out.println(Sum_Power.getSumofPower(a, b));
}
}
