
public class mcq_Program {

		int planets;
		static int suns;
		public void gaze() {
		int i,j;
		i=this.planets;
	 j=this.suns;
	 this.suns=this.planets;
		
		}
		}
	

