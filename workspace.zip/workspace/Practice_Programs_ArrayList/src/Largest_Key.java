import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Largest_Key {
	static String largest(HashMap<Integer,String>hm)
	{
		int max=0;
		String s2="";
		Iterator it=hm.keySet().iterator();
		while(it.hasNext())
		{
			int a= (int) it.next();
			if(a>max)
			{
				max=a;
				String s3=hm.get(a);
				s2=s3;
			}
		}
		return s2;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	HashMap<Integer,String> hm=new HashMap<Integer,String>();
	for(int i=0;i<a;i++)
	{
		hm.put(sc.nextInt(), sc.next());
	}
	System.out.println(Largest_Key.largest(hm));
	
}
}
