
public class UserMainCode {
static int checkPalindrome(String string) {
StringBuffer stringBuffer = new StringBuffer(string);
if(stringBuffer.reverse().toString().equals(string)) {
if(adjacentNonVowel(string) == 1)
return 1;
}
return 0;
}
static int adjacentNonVowel(String string) {
char[] character = string.toCharArray();
for(int i=0; i<character.length-1; i++) {
if(!Character.toString(character[i]).matches("[aeiouAEIOU]"))
if(Character.toString(character[i+1]).equals(Character.toString(character[i])))
return 1;
}
return 0;
}
} 
