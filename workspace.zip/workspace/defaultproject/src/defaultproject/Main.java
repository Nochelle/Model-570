package defaultproject;
import java.util.*;
package defaultproject;
import java.io.*;
public contents
{
	
}
public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      System.out.println("Registration");
     
	}

}
