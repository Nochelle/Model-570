import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HotelRoom extends Room {
	String roomtype;
	String wifi;
	String roomName;
	String capacity;
	String soundSystem;
	public HotelRoom(String roomtype,String wifi) {
		super();
		this.roomtype=roomtype;
		this.wifi=wifi;
	}
	public void hotel_room(String roomtype,String Wifi) throws IOException
	{
		
		Room r=new Room();
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Room Type\n1.Single\n2.Double\n3.Delux");
	    roomtype=b.readLine();
		if(roomtype.equals("1"))
		{
			roomtype="Normal";
		}
		else if(roomtype.equals("2"))
		{
			roomtype="Delux";
		}
		else if(roomtype.equals("3"))
		{
			roomtype="Super Delux";
		}
		System.out.println("Need WiFi ??(true/false)");
		wifi=b.readLine();
		System.out.println("Do you want to add another room?(y/n)");
		String s=b.readLine();
		if(s.equals("y"))
		{
			 r.room();
		}
	}
			/*if(roomType.equals("Single"))
			{
				 rate=1000;
			}
			else if(roomType.equals("Double"))
			{
				 rate=1500;
			}
			else if(roomType.equals("Delux"))
			{
				 rate=2000;
			}
			else if(roomType.equals("Party"))
           {
			 rate=200;
           }
			else 
			{
				rate=250;
			}
			*/
	
	
}
	
	
	


