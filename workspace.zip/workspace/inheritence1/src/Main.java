import java.util.*;
import java.io.*;
public class Main{
	
	public static void main(String[] args) throws IOException
	{
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		Hotel h=new Hotel();
		h.display();
		
		
		
	}
}