import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
public class Hotel{
String name, hotelId, address;
static String reserved=""; 
ArrayList<Room> robj = new ArrayList<Room>();
int roomId=0;
String capacity;
String soundSystem;
String Wifi;
String rate;
String roomName;
String roomtype;
public void addRoom(Room rom)
{
	robj.add(rom);	
}
public void display() throws IOException
{
	BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
	
	//roomId=roomId+1;
	System.out.println("Enter the Hotel details");
	System.out.println("Enter the Hotel name");
	String name=b.readLine();
	System.out.println("Enter the Hotel Location");
	String loaction=b.readLine();
		System.out.println("Enter the Room name\n1.Hotel Room\n2.Hall");
		roomName=b.readLine();
		HotelRoom hr=new HotelRoom(roomtype,Wifi);
		Hall ha=new Hall(capacity, soundSystem);
		if(roomName.equals("1"))
		{
			hr.hotel_room(roomtype, Wifi);
		}
		else if(roomName.equals("2"))
		{
			ha.hall();
		}
		
		//roomId=roomId+1;
	
	/*if(s.equals("n"))
	{
		System.out.println("Hotel Room Details");
		if(roomName.equals("Hotel Room"))
		{
			System.out.println("Lodge Room");
		}
		else
		{
			System.out.println("Conference Hall");
		}
		System.out.println("room ID:"+roomId);
		System.out.println("Capacity:"+capacity);
		System.out.println("Sound System :"+soundSystem);
		System.out.println("wifi :"+Wifi);
		System.out.println("Room Rate :"+rate);	
	}*/
	
}
private void hotel_room() {
	// TODO Auto-generated method stub
	
}
}

