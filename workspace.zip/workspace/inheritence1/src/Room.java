import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;


public class Room {
	
int id,rate,hours;
String Wifi;
String roomtype;
String soundSystem;
String capacity;
public Room(int id,int rate,int hours)
{
	this.id=id;
	this.rate=rate;
	this.hours=hours;
}

public Room() {
	// TODO Auto-generated constructor stub
}

public  void room() throws IOException {
	// TODO Auto-generated method stub
BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
	
	
	HotelRoom hr=new HotelRoom(roomtype,Wifi);
	
	Hall ha=new Hall(capacity, soundSystem);
	System.out.println("Enter the Room name\n1.Hotel Room\n2.Hall");
	 String roomName = b.readLine();
	if(roomName.equals("1"))
	{
		hr.hotel_room(roomtype, Wifi);
	}
	else if(roomName.equals("2"))
	{
		ha.hall();
	}
	System.out.println("Enter the Room Type\n1.Single\n2.Double\n3.Delux");
    roomtype=b.readLine();
	if(roomtype.equals("1"))
	{
		roomtype="Normal";
	}
	else if(roomtype.equals("2"))
	{
		roomtype="Delux";
	}
	else if(roomtype.equals("3"))
	{
		roomtype="Super Delux";
	}
	System.out.println("Need WiFi ??(true/false)");
	String wifi=b.readLine();
}
}




