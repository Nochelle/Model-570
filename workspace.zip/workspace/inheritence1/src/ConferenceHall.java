import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ConferenceHall {
	String wifiHal;
	String projector;
	
	public void confi(String capacity,String soundSystem,String WifiHal,String Projector) throws IOException
	{
		Room r=new Room();
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Capacity");
		capacity=b.readLine();
			System.out.println("Need soundSystem ??(true/false)");
			 soundSystem=b.readLine();
			System.out.println("Need WiFi ??(true/false)");
			 WifiHal=b.readLine();
			System.out.println("Need Projector ??(true/false)");
			String projector=b.readLine();
			System.out.println("Do you want to add another room?(y/n)");
			String s=b.readLine();
			if(s.equals("y"))
			{
				 r.room();
			}
			else
			{
				
			}
	}
}
