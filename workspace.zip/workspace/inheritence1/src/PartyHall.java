import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PartyHall extends Hall {
	
	public PartyHall(String type,String amenities) {
		super(type,amenities);
		this.type=type;
		this.amenities=amenities;
		
		// TODO Auto-generated constructor stub
	}
	
	String type;
	String amenities;
	public void party(String capacity, String soundSytsem,String Wifi) throws IOException
	{
		Room r=new Room();
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Capacity");
		capacity=b.readLine();
			System.out.println("Need soundSystem ??(true/false)");
			 soundSystem=b.readLine();
			System.out.println("Need WiFi ??(true/false)");
			 Wifi=b.readLine();
			 System.out.println("Do you want to add another room?(y/n)");
				String s=b.readLine();
				if(s.equals("y"))
				{
					 r.room();
				}
				else
				{
					
				}
				
	}
}