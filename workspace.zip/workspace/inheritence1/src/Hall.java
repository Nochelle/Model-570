import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Hall extends Room{
	String capacity;
	String soundSystem;
	String amenities;
	String Wifi;
	String WifiHal;
	String Projector;
	public Hall(String capacity, String soundSystem) {
		super();
		this.capacity=capacity;
		this.soundSystem=soundSystem;
		// TODO Auto-generated constructor stub
	}
	public void hall() throws IOException
	{
		BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Hall Type\n1.Party hall\n2.Conference Hall");
	   String type  = b.readLine();
	 
	
	PartyHall ph=new PartyHall(type,amenities);
	   ConferenceHall ch=new ConferenceHall();
	    if(type.equals("1"))
	    {
	    	ph.party(capacity,soundSystem,Wifi);
	    }
	    else
	    {
			ch.confi(type, type, WifiHal, Projector);
	    }
	}
	

	
	
	

}
