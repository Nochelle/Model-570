import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class Main 
{
	public static void main(String[] args)
	{
		String fn;
		String ln;
		String cn;
		String em;
		String pt;
		String pi;
		String p;
		int count=0;
		Scanner sc = new Scanner(System.in); 
			System.out.println("Customer Registration:");
			System.out.println();
			System.out.println("Enter the customer details:");
			System.out.println("Enter the first name:");
			 fn=sc.next();
			System.out.println("Enter the last name:");
			 ln=sc.next();
			System.out.println("Enter the contact number:");
			 cn=sc.next();
			 System.out.println("Enter the e-mail id:");
			do{
			 em=sc.next();}while(roomNum(em));
	
		System.out.println("Enter the proof type:");
			 pt=sc.next();
			System.out.println("Enter the proof id:");
			 pi=sc.next();
			 Customer c = new Customer(fn,ln,cn,em,pt,pi);
			 display(c);
	}
	private static void display(Customer c)
	{
		System.out.println("Thank you for registering. Your id is 1..\nThe customer details are as follows");
		
			System.out.println(c.toString());
		
		
		}
	public static boolean roomNum(String email){
		
		try{
		
		if(!email.matches("[a-zA-Z0-9.]{1,}+@[a-zA-Z0-9\\-\\_\\.]+\\.[a-zA-Z0-9]{3}")){
			throw new Exceptioncl();
		}
		}catch(Exceptioncl ex){
			System.out.println(ex.getMessage());
			return true;
		}
		return false;
	}
}  
