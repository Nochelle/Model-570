
public class Exceptioncl extends Exception {
	public String getMessage(){
		return ("Invalid Email ID\nRe-enter Email ID");
	}
}
