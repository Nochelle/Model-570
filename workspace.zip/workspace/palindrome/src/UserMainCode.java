
public class UserMainCode {
	static void isPalindrome(String s)
	{
		 StringBuffer str1 = new StringBuffer(s);
         StringBuffer str2 = new StringBuffer(s);
         str1.reverse();
        
		if(String.valueOf(str1).compareTo(String.valueOf(str2))==0)

           System.out.println(str2+" is a palindrome");

        else
            System.out.println(str2+" is not a palindrome");
		
		
	}
}

