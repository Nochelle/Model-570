import java.util.Scanner;

public class Main {
   public static void main(String[] args)
	        {
	            String s;
				
	            Scanner scan =new Scanner (System.in);
	           
	            s = scan.nextLine();
	            UserMainCode u=new UserMainCode();
	            u.isPalindrome(s);
	            
	            
	        }
	   
	}


