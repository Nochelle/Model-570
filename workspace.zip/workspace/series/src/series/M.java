package series;

import java.util.Scanner;

public class M {
	public double re,im;
	public M (double re,double im)
	{
		this.re=re;
		this.im=im;
	}
    

		public static void main(String[] args)
		{
			M c1=new M(10,15);
			M c2=new M(10,15);
			if(c1.equals(c2))
			{
				System.out.println("equal");
			}
			else
			{
				System.out.println("not equal");
			}
			
		    
		 
		   
	
		
		}


		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			long temp;
			temp = Double.doubleToLongBits(im);
			result = prime * result + (int) (temp ^ (temp >>> 32));
			temp = Double.doubleToLongBits(re);
			result = prime * result + (int) (temp ^ (temp >>> 32));
			return result;
		}


		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			M other = (M) obj;
			if (Double.doubleToLongBits(im) != Double.doubleToLongBits(other.im))
				return false;
			if (Double.doubleToLongBits(re) != Double.doubleToLongBits(other.re))
				return false;
			return true;
		}
		}
	

