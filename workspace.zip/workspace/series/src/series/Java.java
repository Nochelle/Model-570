package series;
import java.util.*;

public class Java {
	public static void main(String[] args)
	{
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();
		System.out.println(a);
		StringBuilder input=new StringBuilder();
		input.append(input);
		input=input.reverse();
		System.out.println(input);
		
	}
}
