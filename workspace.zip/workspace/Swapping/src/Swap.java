
public class Swap {
	public static void main(String[] args) {
		int a,b,c = 0;
		a=1;
		b=2;

		System.out.print("a is ");
		System.out.println(a);
		System.out.print("b is ");
		System.out.println(b);
		c=a;
		a=b;
		b=c;

		System.out.print("a is ");
		System.out.println(a);
		System.out.print("b is ");
		System.out.println(b);

	}


}
