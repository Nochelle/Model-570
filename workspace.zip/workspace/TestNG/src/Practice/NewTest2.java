package Practice;

public class NewTest2 {

}
