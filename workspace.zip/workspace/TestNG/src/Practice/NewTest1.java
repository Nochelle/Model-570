package Practice;

public class NewTest1 {
	

}
