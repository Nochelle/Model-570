package Practice;

public class NewTest3 {

}
