import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestingNG_Practice4 {
	@Test
	public void display()
	{
		System.out.println("hai");
	}
	@BeforeMethod
	public void work()
	{
		System.out.println("hiii");
	}
	@Test
	public void page()

	{
		System.out.println("Hi");
	}


}
