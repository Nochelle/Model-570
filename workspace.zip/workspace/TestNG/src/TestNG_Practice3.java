import org.testng.annotations.Test;

public class TestNG_Practice3 {
	@Test
	public void display()
	{
		System.out.println("hai");
	}
	@Test(dependsOnMethods={"display"})
	public void work()
	{
		System.out.println("hiii");
	}
	@Test
	public void page()

	{
		System.out.println("Hi");
	}
}

