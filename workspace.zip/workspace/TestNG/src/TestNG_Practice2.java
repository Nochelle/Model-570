import org.testng.annotations.Test;

public class TestNG_Practice2 {
	@Test(description="Login")
	public void display()
	{
		System.out.println("hai");
	}
	@Test
	public void work()
	{
		System.out.println("hai");
	}
	@Test(enabled=true)
	public void hef()

	{
		System.out.println("Hi");
	}


}
