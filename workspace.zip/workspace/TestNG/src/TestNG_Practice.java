import org.testng.annotations.Test;

public class TestNG_Practice {
	@Test(priority=1)
	public void display()
	{
		System.out.println("hai");
	}
	@Test(priority=3)
	public void work()
	{
		System.out.println("hai");
	}
	@Test(priority=2)
	public void testing()

	{
		System.out.println("Hi");
	}


}
