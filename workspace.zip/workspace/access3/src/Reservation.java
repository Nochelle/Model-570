public class Reservation {
String customer, room, checkInDate, checkOutDate,bookingDate;
public Reservation(String cus,String room,String checkin,String checkout,String booking)
{
	this.customer=cus;
	this.room=room;
	this.checkInDate=checkin;
	this.checkOutDate=checkout;
	this.bookingDate=booking;
}
} 