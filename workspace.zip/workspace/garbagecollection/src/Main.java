import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class Main {

	public static void cusdetails(String cusname,String cuslname,String cuscontact,String cusmail,String cusprooftype,String cusproof)
	{ 
System.out.println("The customer details are as follows\nThe customer details are:");
		System.out.println("First Name : "+cusname);
		System.out.println("Last Name : "+cuslname);
		System.out.println("Contact Number : "+cuscontact);
		System.out.println("E-Mail : "+cusmail);
		System.out.println("Proof Type : "+cusprooftype);
		System.out.println("Proof ID : "+cusproof);
		
		
	}
	public static void main(String[] args) throws  IOException {
		Reservation r=new Reservation();
		int checkyes,space=1;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String  roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry,yn,yesno;
		ArrayList namecustomer=new ArrayList(); 
System.out.println("\nEnter the Hotel details:");
		System.out.println("Enter the Hotel Name:");
		String name=br.readLine();
		System.out.println("Enter the Hotel ID:");
		String hotelId=br.readLine();
		System.out.println("Enter the Hotel Address");
		String address=br.readLine();
		do{
		System.out.println("Enter the Room Details:");
		System.out.println("Enter the Room Id:");
		roomId=br.readLine();
		System.out.println("Enter the Room Number:");
		roomNumber=br.readLine();
		System.out.println("Enter the Room Type:");
		System.out.println("1)Normal");
		System.out.println("2)Delux");
		System.out.println("3)Super Delux");
		roomType=br.readLine();
		System.out.println("Enter the Room Capacity:(1/2/3/4)");
		roomCapacity=br.readLine();
		System.out.println("AC Service (true/false):");
		roomAc=br.readLine();
		System.out.println("Wi-Fi Service (true/false):");
		roomWifi=br.readLine();
		System.out.println("Cable Service (true/false):");
		roomCabel=br.readLine();
		System.out.println("Laundry Service (true/false):"); 

roomLaundry=br.readLine();
		System.out.println("Do you want to add Another Room (yes/no):");
		yn=br.readLine();
		
		r.addRoom(roomType, roomNumber, roomAc, roomWifi, roomCabel, roomLaundry);
		
		r.addCheck(roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry);
		
	}while(yn.equals("yes"));
	
		
		if(yn.equals("no"))
		{
			Reservation h=new Reservation(name, hotelId, address);
			Reservation.display();
		}
		
		do{
		System.out.print("Reservation\n");
		System.out.println("\nCustomer Registration:\n");
		System.out.println("Enter the customer details:\nEnter the first name:");
		String cusname=br.readLine();
		System.out.println("Enter the last name:");
		String cuslname=br.readLine();
		System.out.println("Enter the contact number:");
		String cuscontact=br.readLine();
		System.out.println("Enter the e-mail id:");
		String cusmail=br.readLine();
		System.out.println("Enter the proof type:");
		String cusprooftype=br.readLine();
		System.out.println("Enter the proof id:");
		String cusproof=br.readLine();
		System.out.println();
		 
namecustomer.add(cusname);
		cusdetails(cusname,cuslname,cuscontact,cusmail,cusprooftype,cusproof);do{
			System.out.println("\nEnter the room requirements:");
			System.out.println("Enter the Room Type:");
			System.out.println("1)Normal");
			System.out.println("2)Delux");
			System.out.println("3)Super Delux");
			String cusroomType=br.readLine();
			System.out.println("Enter the Room Capacity:(1/2/3/4)");
			String cusroomCapacity=br.readLine();
			System.out.println("AC Service (true/false):");
			String cusroomAc=br.readLine();
			System.out.println("Wi-Fi Service (true/false):");
			String cusroomWifi=br.readLine();
			System.out.println("Cable Service (true/false):");
			String cusroomCabel=br.readLine();
			System.out.println("Laundry Service (true/false):");
			String cusroomLaundry=br.readLine();
			r.addcus(cusroomType, cusroomCapacity, cusroomAc, cusroomWifi, cusroomCabel, cusroomLaundry);
		  checkyes=r.check();
			if(checkyes==3)break;
			}while(checkyes==1); 
	System.out.println("\nEnter the Booking date(MM/dd/yyyy)");
			String bd=br.readLine();
			System.out.println("Enter the check-in date(MM/dd/yyyy)");
			String cd=br.readLine();
			System.out.println("Enter the check-out date(MM/dd/yyyy)");
			String cod=br.readLine();
			r.adddates(bd, cd, cod);
			
					System.out.println("Do you want to perform another reservation?(y/n)");
					yesno=br.readLine();
		}while(yesno.equals("y"));
			
			System.out.println("The reservation details are as follows:\n");
			r.displayfinal(namecustomer);
			System.gc();
	}
	}   