import java.util.Scanner;


public  class Room implements Runnable{
	
	//String price="";
	public Room(long days,long totalBill) {
		Thread r1=new Thread(this);
		r1.setName("Room Service Initiated for the room ");
		Thread r2=new Thread(this);
		r2.setName("Room checking is going on");
		Thread r3=new Thread(this);
		r3.setName("Room Service is clear - You can proceed with checkout process");
		Thread r4=new Thread(this);
		r4.setName("The total rent for "+days+" Days is "+totalBill);
		try{
		r1.start();
		r1.join();
		r2.start();
		r2.join();
		r3.start();
		r3.join();
		r4.start();
		//r4.join();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			
		}
		
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			System.out.println(Thread.currentThread().getName());
			Thread.sleep(2000);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
	}
 

