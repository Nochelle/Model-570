import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
public class Main {
	static String cindate;
	static String coutdate;
	static String choice;
	static String room;
	static long totalBill;
	static long days;
	static long bill;
	

	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Do you want to check out yes/no");
		choice=sc.nextLine();
		
		if(choice.equals("yes"))
		{
		System.out.println("Enter the check-in date");
		 cindate=sc.nextLine();
		System.out.println("Enter the check-out date");
		 coutdate=sc.nextLine();
		System.out.println("Enter the Room Type:\nNormal\nDeluxe\nSuper Deluxe");
		room=sc.nextLine();
		if(room.equals("Normal"))
			bill=1500;
		else if(room.equals("Deluxe"))
			bill=2500;
		else if(room.equals("Super Deluxe"))
			bill=3500;
		else
			room=sc.nextLine();
	    days=dateDiff(cindate,coutdate);
	    totalBill=bill*days;
	   Room room=new Room( days, totalBill);
		}
		else
		System.out.println("Thank you for continuing your stay");
		
		
		
	}

	static public long dateDiff(String date1,String date2) {
		 
		 SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		 Date d1=null;
		 Date d2=null;
		 long diff;
		 try {
		        d1 = (Date) format.parse(date1);
		        d2 = (Date) format.parse(date2);
		    } catch (ParseException e) {
		        e.printStackTrace();
		    }

	      diff=(long)(d2.getTime() - d1.getTime());
	      long day= (diff/(1000*60*60*24)%7);
	      return day;
		
	}

}
 
