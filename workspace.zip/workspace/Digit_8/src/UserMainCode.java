
public class UserMainCode {
	public static int countEight(int x) {
		int r,count=0;
		while(x>0)
		{
			r=x%10;
			if(r==8)
			{
				count++;
			}
			x=x/10;
		}
		return count ;
	}
}
