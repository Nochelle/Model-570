
import java.util.*;
public class Room {
	
String roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry;
public Room(String roomId, String roomType, String roomNumber, String roomCapacity, String roomAc, String roomWifi, String roomCabel, String roomLaundry)
{
	this.roomId=roomId;
	this.roomType=roomType;
	this.roomNumber=roomNumber;
	this.roomCapacity=roomCapacity;
	this.roomAc=roomAc;
	this.roomWifi=roomWifi;
	this.roomCabel=roomCabel;
	this.roomLaundry=roomLaundry;

}
}  
