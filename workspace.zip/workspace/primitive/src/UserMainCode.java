import java.util.*;

public class UserMainCode {
	static int findRupees(String s)
	{
	char[] charc = s.toCharArray();
	
	int rupees = 0, position=0;
	
	char[] keyboards = {'q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m'};
	
	for(int i =0 ; i< charc.length ; i++ ){
		for(int j =0; j< 26 ; j++){
		if( charc[i] == keyboards [j] ){
			
			
			rupees +=  Math.abs(position - j);
			position = j;
			
			}
		}
	}
	return rupees; 
	}
}