import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;  
public class Main {
	
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
	static ArrayList<Integer> customerIdList = new ArrayList<Integer>();
	static ArrayList<String> CustomerNameList = new ArrayList<String>(); 
static void viewCustomers(ArrayList<Integer> customerIdList,ArrayList<String> CustomerNameList){
System.out.println("Customers list\nThe registered customers are");
		
		System.out.format("%-15s%-15s\n","Customer ID","Customer name");
		
		for(int j =0; j<customerIdList.size(); j ++){
		System.out.format("%-15d%-15s\n",customerIdList.get(j),CustomerNameList.get(j));
			
		}
		System.out.println("Thank You");
	}  
public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		
		String reg;
		
		int id = 0;
		
		do{ 
System.out.println("Registration");
		System.out.println("Enter your name");
		String name=br.readLine();
		CustomerNameList.add(name);
		System.out.println("Enter your address");
		String address=br.readLine();
		System.out.println("Contact Number");
		String contactNumber=br.readLine();
		System.out.println("E-Mail ID");
		String email=br.readLine();
		System.out.println("Enter proof type");
		String proofType=br.readLine();
		System.out.println("Enter proof id");
		String proofID=br.readLine();  
customerIdList.add(++id);  
 System.out.println("Thank you for registering. Your id is " + id + ".");
		
		System.out.println("Do you want to continue registration (y/n)?"); 
reg = br.readLine();
		
		}while(reg.equals("y"));
		
		if(reg.equals("n")){
			viewCustomers(customerIdList, CustomerNameList );
		}

}
}
