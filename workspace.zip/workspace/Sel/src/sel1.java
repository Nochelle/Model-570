import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class sel1 {
public static void main(String[] args) throws Exception
{
	System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("http://toolsqa.com/automation-practice-form/");
	WebElement head=driver.findElement(By.xpath("//*[@id='Form_requestDemo_LastName_Holder']/label"));
	head.getText();
	System.out.println("headtext=="+head.getText()); 
}
}

