import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class s10{
public static void main(String[] args)
{
	System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	
	driver.get("http://toolsqa.com/automation-practice-switch-windows/");
	String handle=driver.getWindowHandle();
	System.out.println(handle);
	driver.findElement(By.xpath("//*[@id='content']/p[3]/button")).click();
	Set<String> handles=driver.getWindowHandles();
			System.out.println(handles);
			for(String handle1:driver.getWindowHandles())
			{
				System.out.println(handle1);
				driver.switchTo().window(handle1);
				driver.close();
				driver.quit();
			}
}
}