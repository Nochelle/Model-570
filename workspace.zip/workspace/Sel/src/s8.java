import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class s8{
public static void main(String[] args)
{
	System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	
	driver.get("http:////jqueryui.com/");
	List<WebElement> lis=driver.findElements(By.tagName("a"));
	for(int i=0;i<lis.size();i++)
	{
		System.out.println(lis.get(i).getText());
	}
}
}
