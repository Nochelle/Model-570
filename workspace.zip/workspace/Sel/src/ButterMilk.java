
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.swing.JOptionPane; 

public class ButterMilk {
	
	public static void main(String args[]) throws IOException, InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		 
		driver.manage().window().maximize();
		
		driver.navigate().to("http://www.echoecho.com/htmlforms09.htm");
		
		
		JOptionPane.showMessageDialog(null, "infoMessage", "InfoBox: " , JOptionPane.INFORMATION_MESSAGE);
		
		///JOptionPane.showMessageDialog(null, "Click ok");
		WebElement butter =  driver.findElement(By.xpath("//input[@value=\"Butter\"]"));
		
		
		WebElement milk= driver.findElement(By.xpath("//input[@value=\"Milk\"]"));
		
		if(!butter.isSelected())
		{
			butter.click();
		}
		
		 if(!milk.isSelected())
		{
			milk.click();
		}
//		
		
		
	
	
	}
	
		
} 
