import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyContact {
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://www.mycontactform.com/samples.php");
		driver.findElement(By.xpath("//td[contains(.,'Text Box Field')]//input")).sendKeys("hi");
	}
}
