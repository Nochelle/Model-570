import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Framework {
	
   public static void main(String[] args) throws IOException
   {
	   FileInputStream file=new FileInputStream("D://LeadSuite.xlsx");
	   XSSFWorkbook workbook=new XSSFWorkbook(file);
	   XSSFSheet sheet=workbook.getSheetAt(0);
	   int rowcount=sheet.getLastRowNum();
	   System.out.println(rowcount);
	   for(int i=0;i<=rowcount;i++)
	   {
		   XSSFRow row=sheet.getRow(i);
		   XSSFCell cell=row.getCell(0);
		   String username=cell.getStringCellValue();
		   XSSFCell cell1=row.getCell(1);
		   String password=cell1.getStringCellValue();
		   XSSFCell cell2=row.getCell(2);
		   String FirstName=cell2.getStringCellValue();
		   XSSFCell cell3=row.getCell(3);
		   String LastName=cell3.getStringCellValue();
		   System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		   WebDriver driver=new ChromeDriver();
		   driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		   driver.get("http://demo.borland.com/InsuranceWebExtJS/index.jsf");
		  /* WebElement ele=driver.findElement(By.xpath("//*[@id='quick-link:jump-menu']"));
		   Select sel=new Select(ele);
		   sel.selectByIndex(1);*/
		   driver.findElement(By.xpath("//*[@id='login-form:email']")).sendKeys(username);
		   driver.findElement(By.xpath("//*[@id='login-form:password']")).sendKeys(password);
		   driver.findElement(By.xpath("//*[@id='login-form:signup']")).click();
		   driver.findElement(By.xpath("//*[@id='signup:fname']")).sendKeys(FirstName);
		   driver.findElement(By.xpath("//*[@id='signup:lname']")).sendKeys(LastName);
//		   driver.findElement(By.xpath("//*[@id='login-form:email']")).sendKeys(username);
//		   driver.findElement(By.xpath("//*[@id='login-form:email']")).sendKeys(username);
		   
	   }	   
   }
}
