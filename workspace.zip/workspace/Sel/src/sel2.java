import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class sel2 {
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://toolsqa.com/automation-practice-form/");
		WebElement ele=driver.findElement(By.id("continents"));
	    Select sel=new Select(ele);
	    sel.selectByIndex(1);
	    WebElement ele1=driver.findElement(By.id("selenium_commands"));
	    Select sel1=new Select(ele1);
	    sel1.selectByIndex(0);
	    sel1.selectByIndex(1);
	    sel1.selectByIndex(2);
	    sel1.selectByIndex(3);
	    sel1.deselectByIndex(0);
	    sel1.deselectByIndex(1);
	    sel1.deselectByIndex(2);
	}
}

