import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel3 {
public static void main(String[] args)
{
	System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	driver.get("http:////jqueryui.com/");
	driver.findElement(By.linkText("Download"));
	driver.findElement(By.linkText("Development"));
	driver.navigate().back();
	driver.navigate().forward();
	driver.navigate().refresh();
}
}
