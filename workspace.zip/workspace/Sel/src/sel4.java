import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class sel4 {
public static void main(String[] args) throws Exception
{
	System.setProperty("webdriver.ie.driver","D:\\Selenium\\Selenium softwares\\IE Driver\\IEDriverServer_x64_3.12.0\\IEDriverServer.exe");
	WebDriver driver=new InternetExplorerDriver();
	driver.manage().window().maximize();
	driver.get("http://toolsqa.com/automation-practice-form/");
	WebElement head=driver.findElement(By.xpath("//*[@id='Form_requestDemo_LastName_Holder']/label"));
	head.getText();
	System.out.println("headtext=="+head.getText()); 
}
}
