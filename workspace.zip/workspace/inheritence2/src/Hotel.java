import java.util.ArrayList;
import java.util.List;

public class Hotel {
	String name, address;
	int hotelId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public List<Room> getRoomList() {
		return roomList;
	}

	public void setRoomList(List<Room> roomList) {
		this.roomList = roomList;
	}

	List<Room> roomList = new ArrayList<>();

	void addRoom(Room obj2) {
		roomList.add(obj2);
	}

	void display() {
		int cnt = roomList.size();
		System.out.println("Hotel Room Details : ");
		for (int i = 0; i < cnt; i++) {
			Room r = roomList.get(i);
			r.display();
		}
	}
}

