public class ConferenceHall extends Hall {
	boolean wifiHall, projector;

	public ConferenceHall(int roomid, int hours, int rate, int capacity, boolean soundSystem, boolean wifiHall,
			boolean projector) {
		super(roomid, hours, rate, capacity, soundSystem);
		this.wifiHall = wifiHall;
		this.projector = projector;
	}

	void display() {
		System.out.println("Conference Hall");
		System.out.println("Room ID : " + roomid);
		System.out.println("Capacity : " + capacity);
		System.out.println("Sound System : " + soundSystem);
		System.out.println("Wifi : " + wifiHall);
		System.out.println("Projector : " + projector);
		System.out.println("Room Rate : " + rate);
		System.out.println();
	}
}