public class Room {
	int roomid, hours;
	int rate;
	static String roomId;
	String roomType;
	static String roomNumber;
	static String roomCapacity;
	static String roomAc;
	static String roomWifi;
	static String roomCabel;
	static String roomLaundry; 

	public Room() {
	}

	public Room(int roomid, int hours, int rate,String roomId, String roomType, String roomNumber,String  roomCapacity,String roomAc, String roomWifi,String roomCabel,String roomLaundry) {
		this.roomid = roomid;
		this.hours = hours;
		this.rate = rate;
		this.roomAc=roomAc;
		this.roomCabel=roomCabel;
		this.roomCapacity=roomCapacity;
	}

	void display() {
	}
}