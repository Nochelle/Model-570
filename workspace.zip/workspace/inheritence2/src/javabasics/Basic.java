package javabasics;

public class Basic {
	static int i=11- -12 - -13- -14 - - + + + + + + +15;
public static void main(String[] args) {
	System.out.println(i);
}
}
