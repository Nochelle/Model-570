import java.util.*;

public class Customer {
	 String fName, lName, eMail, proofType, contactNumber,tdate,cdate ; 
	 int proofId,days,rate;
	 public void registerCustomer(String fName,String lName,String contactNumber,String eMail,String proofType,int proofId)
	 {
		 System.out.println("Thank you for registering.");
		 System.out.println("The customer details are as follows");
		 System.out.println("First Name :"+fName);
		 System.out.println("Last Name :"+lName);
		 System.out.println("Contact Number :"+contactNumber);
		 System.out.println("E-Mail :"+eMail);
		 System.out.println("Proof Type : "+proofType);
		 System.out.println("Proof ID : "+proofId);
	 }
	 public void display(String tdate,String cdate,int days,int rate)
	 {
		
		System.out.println("Booking Date : "+tdate);
		System.out.println("Check in Date : "+cdate);
		System.out.println("No of Days :"+days);
		System.out.println("Room Rate :  "+rate);
		int a=days*100;
		System.out.println("Wifi Charges ( @ 100 per day ) :  "+a);
		
		System.out.println("Vat 10 % : "+tdate);
		System.out.println();
		
		System.out.println("Total :"+tdate);
	 }
	/*
		 System.out.println("AVAILABILITY CHECK");
		 		
		 		for (int j = 0; j < roomDetails.size(); j++) {
		 			Room r = roomDetails.get(j);
		 			if( ( r.roomName == CroomName && (r.hallType == ChallType || (r.roomType == CroomType ) )  )){
		 				if(r.roomWifi == Cwifi || r.roomProjector == Cprojector || r.roomCapacity == Ccapacity || r.roomSound == CsoundSystem ){
		 					
		 					System.out.println("Room Number :" + r.roomNumber);
		 					CroomRate = r.sum;
		 					break;
		 				}
		 			}
		 		}*/
		 		
		 		/*System.out.println("Enter the number of days :");
		 		int days = Integer.parseInt(br.readLine());
		 		System.out.println("Enter today's date :"); 
		 		String startDate = br.readLine();
		 		System.out.println("Enter check in date :");
		 		String lastDate = br.readLine();
		 		System.out.println("Booking Date : " + startDate) ;
		 		System.out.println("Check in Date : " + lastDate);
		 		System.out.println("No of Days : " + days);
		 		System.out.println("Room Rate : " + (CroomRate*days));
		 		System.out.println("Wifi Charges ( @ 100 per day ) : " + (days*100));
		 		int vat = ( (days*100 + (CroomRate*days)) * 10)/100  + ((days*100)*10/100 );
		 		System.out.println("Vat 10 % : " + (vat));
		 		System.out.println();
		 		System.out.println("Total : " + ((CroomRate*days)+vat + (days*100) + (days*100)  ));*/

		 	} 

}
