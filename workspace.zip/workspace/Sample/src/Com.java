
public class Com {
 static int _=2;
 static int $=3;
 static int _$=7;
 static int $_=10;
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println(_);
 System.out.println($);
 System.out.println(_$);
 System.out.println($_);
 
	}

}
