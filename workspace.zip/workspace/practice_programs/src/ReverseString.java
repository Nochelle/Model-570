import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ReverseString {
public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	ArrayList<String> list=new ArrayList<String>();
	for(int i=0;i<a;i++)
	{
		list.add(sc.next());
	}
	String s=sc.next();
	//Collections.sort(list);
	System.out.println(list);
	Collections.reverse(list);
	System.out.println(list);
	for(int i=0;i<a;i++)
	{
		if(s.equals(list.get(i)))
		{
			System.out.println(i+1);
		}
	}

}
}
