import java.util.Scanner;

public class Data_Mining {
	public static void main(String[] args) {
		int p=0,q=0;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		while(a>0)
		{
			if((a%10)%2==0)
			{
				p=p+a%10;
				a=a/10;
			}
			else
			{
				q=q+a%10;
				a=a/10;
			}
		}
		if(p==q)
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");
		}

	}

}
