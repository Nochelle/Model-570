import java.util.Scanner;

public class Maximum_Program {
	static int max=0;
	static int max(int a,int b,int c){
		if(a>b&&a>c)
		{
			max=a;
		}
		else if(b>c)
		{
			max=b;
		}
		else
		{
			max=c;
		}
		return max;
	}
public static void main(String[] args) {
	int f,g,h;
	Scanner sc=new Scanner(System.in);
	f=sc.nextInt();
	g=sc.nextInt();
	h=sc.nextInt();
	Maximum_Program m=new Maximum_Program();
	System.out.println(m.max(f, g, h)+" is a Maximum Number");
	
}
}
