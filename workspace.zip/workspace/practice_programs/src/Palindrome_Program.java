import java.util.Scanner;

public class Palindrome_Program {

	    public static void main(String[] args){  
	       Scanner sc=new Scanner(System.in);
	       String input=sc.nextLine();
	      
	       StringBuilder s1=new StringBuilder(input);
	       StringBuilder s2=new StringBuilder(input);
	    		   s1.reverse();
	       if(String.valueOf(s1).compareTo(String.valueOf(s2))==0)
	      System.out.println("Palindrome");
	       else
	       {
	    	   System.out.println("Not a palindrome");
	       }
	    }  
	}  


