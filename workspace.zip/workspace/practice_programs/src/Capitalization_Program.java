import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.*;

public class Capitalization_Program {
public static void main(String[] args) throws IOException {
	String a,s2,s3;
	
	BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
	a=b.readLine();
	StringTokenizer s=new StringTokenizer(a," ");
	//StringBuilder s1=new StringBuilder(a);
	while(s.hasMoreTokens())
	{
		s2=s.nextToken();
		s3=s2.substring(0,1).toUpperCase()+s2.substring(1,s2.length())+" ";
		System.out.print(s3);
}
}
}