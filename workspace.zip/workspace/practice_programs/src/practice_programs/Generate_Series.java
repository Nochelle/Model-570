package practice_programs;

import java.util.Scanner;

public class Generate_Series {
public static void main(String[] args) {
	int j=0;
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b[]=new int[a];
	for(int i=1;i<=a;i++)
	{
		
		if(i%2!=0)
		{
			
			b[j]=i;
			j++;
		}
		
	}
	int sum=b[0];
	for(int i=1;i<b.length;i++)
	{
		if(i%2!=0)
		{
			sum=sum+b[i];
		}
		else
		{
			sum=sum-b[i];

		}
	}
	System.out.println(sum);
}
}
