package practice_programs;

public class change {
static void doit(int [] z){
int temp=z[z.length-1];
z[1]=temp;

}
public static void main(String[] args) {
	int myarray[]={1,2,3,4,5};
	change.doit(myarray);
	for(int i=0;i<myarray.length;i++){
		System.out.println(myarray[i]);
	}
}
}
