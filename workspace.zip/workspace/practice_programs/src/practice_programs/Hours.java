package practice_programs;

public class Hours {

}
