package practice_programs;

import java.util.Scanner;

public class Character_Check {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	s.toCharArray();
   char a=s.charAt(0);
   char b=s.charAt(s.length()-1);
	if(a==b)
	{
		System.out.println("Valid");
	}
	else
	{
		System.out.println("Invalid");
	}
}
}
