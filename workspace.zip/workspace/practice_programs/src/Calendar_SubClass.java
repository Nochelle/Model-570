import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Calendar_SubClass {
static void CalendarDisplay(String d,String f)
{
	if(d.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}"))
	{
		SimpleDateFormat date1=new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat date2=new SimpleDateFormat("dd-MM-yyyy");
		//SimpleDateFormat date3=new SimpleDateFormat("EEEE");
		date1.setLenient(false);
		date2.setLenient(false);
		//date3.setLenient(false);
		try {
			Date d1=date1.parse(d);
			Date d2=date2.parse(f);
			Calendar c=Calendar.getInstance();
			c.setTime(d1);
			long a=c.getTimeInMillis();
			c.setTime(d2);
			long b=c.getTimeInMillis();
			long diff=Math.abs(a-b);
			long res=diff/(1000*24*60*60);
			//String d3=date3.format(d1);
			//System.out.println(d1);
			//System.out.println(d3);
			System.out.println(res);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	else
	{
		System.out.println("oops!Invalid Date\n Enter Date Again");
	}
	
}
}
