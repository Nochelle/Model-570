import java.nio.charset.MalformedInputException;
import java.util.Scanner;

public class ArrayIndexPower {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int s[]=new int[n];
		for(int i=0;i<n;i++)
		{
			s[i]=sc.nextInt();
		}
		
		System.out.println(ArrayIndexPower.cal(n, s));
	}
	static int cal(int n,int s[])
	{
	int sum=0;
	for(int i=0;i<n;i++)
	{
		sum=(int)(sum+Math.pow(s[i], i));
	}
	return sum;

	}
}
