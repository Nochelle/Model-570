import java.util.Scanner;


public class Main {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	UserMainCode m=new UserMainCode();
	Boolean b=m.isPrime(n);
	if(b)
		System.out.println("Trendy Number");
	else
		System.out.println("Not a Trendy Number");
}
} 
