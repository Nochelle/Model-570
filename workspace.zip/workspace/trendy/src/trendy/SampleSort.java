package trendy;

public class SampleSort {
	public static void main(String[] args) {
		List<String> list=new ArrayList<String>
	}

}
