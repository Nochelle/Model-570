 
public class UserMainCode {
static Boolean isPrime(int a)
{
	Boolean result=false;
	String str=Integer.toString(a);
	int n=str.length();
	if(n==3)
	{
		int b=(a/10)%10;
		if(b % 3==0)
		{
			result=true;
		}
	}
	return result;
}
}   
