import java.util.Arrays;

public class UserMainCode {
	public static int findRange(int[] a) {
		//Fill your Code
		 Arrays.sort(a);
		//System.out.println(a);
		int diff = 0;
		int len=a.length;
		diff=a[len-1]-a[0];
		return diff;
	}
}
