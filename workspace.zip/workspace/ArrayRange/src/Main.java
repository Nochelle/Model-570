import java.util.*;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int i=0;
		int a1 = sc.nextInt();
		int a[] = new int[a1];
		for(i=0;i<a1;i++) {
			a[i] = sc.nextInt();
		}
		System.out.println(UserMainCode.findRange(a));
	}
}
