import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		HashMap <Integer,String> hm=new HashMap<Integer,String>();
		HashMap <Integer,String> hg=new HashMap<Integer,String>();
		for(int i=0;i<n;i++)
		{
			int a=sc.nextInt();
			String b=sc.next();
			String c=sc.next();
			hm.put(a,b);
			hg.put(a,c);
		}
		for(Map.Entry<Integer, String> m:hm.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue()+" "+hg.get(m.getKey()));
		}

		int x=sc.nextInt();
		if(hm.containsKey(x))
		{
		System.out.println(hm.get(x)+" "+hg.get(x));
		}
		else
		{
			System.out.println("Invalid key");
		}
   
	}

}
