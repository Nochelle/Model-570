import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		String fn;
		String ln;
		String cn;
		String em;
		String pt;
		String pi;
		String p;
		int count=0;
		Scanner sc = new Scanner(System.in); 
		System.out.println("Customer Registration:");
		System.out.println();
		List<Customer> t1 = new ArrayList<Customer>();
		do
		{


			System.out.println("Enter the customer details:");
			System.out.println("Enter the first name:");
			fn=sc.next();
			System.out.println("Enter the last name:");
			ln=sc.next();
			System.out.println("Enter the contact number:");
			cn=sc.next();
			System.out.println("Enter the e-mail id:");
			em=sc.next();
			System.out.println("Enter the proof type:");
			pt=sc.next();
			System.out.println("Enter the proof id:");
			pi=sc.next();
			System.out.println("Do you want to add new customer?(y/n)");
			p = sc.next();
			count++;
			Customer c = new Customer(fn,ln,cn,em,pt,pi);
			t1.add(c);
		}
		while(p.equals("y"));
		Collections.sort(t1, new EmployeeSortByName());
		display(t1);
	}

	private static void display(List<Customer> t1)
	{ System.out.println("The customer details are as follows");
	Iterator<Customer> i1 = t1.iterator();

	while(i1.hasNext()){
		System.out.println(i1.next().toString());

		System.out.println();
	}
	}
} 
