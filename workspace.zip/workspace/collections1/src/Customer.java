import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.Comparator;

public class Customer 
{
	String fn;
	String ln;
	String cn;
	String em;
	String pt;
	String pi;
	public Customer(String fn, String ln, String cn, String em, String pt,
			String pi) {
		super();
		this.fn = fn;
		this.ln = ln;
		this.cn = cn;
		this.em = em;
		this.pt = pt;
		this.pi = pi;
	}
	
	public String toString(){
		return ("The customer details are:\nFirst Name : "+fn+"\nLast Name : "+ln+"\nContact Number : "+cn+"\nE-Mail : "+em+"\nProof Type : "+pt+"\nProof ID : "+pi);
	}

	}     

 
// sort by name
class EmployeeSortByName implements Comparator<Customer>  {
    public int compare(Customer emp1,Customer emp2) {
        return emp1.fn.compareTo(emp2.fn);
    }
}   


