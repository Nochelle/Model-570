import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Date_Format {
	static String diffCalculation(String a,String b)
	{
		
		String r = "";
		if(a.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}")&&b.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}"))
		{
			String m,n;
			SimpleDateFormat s=new SimpleDateFormat("dd-MM-yyyy");
		    SimpleDateFormat s1=new SimpleDateFormat("dd/MM/yyyy");
		    s.setLenient(false);
		    s1.setLenient(false);
		    try{
		    	Date d1=s.parse(a);
			    Date d2=s.parse(b);
			    Calendar c=Calendar.getInstance();
			    c.setTime(d1);
			   long y=c.getTimeInMillis();
			   c.setTime(d2);
			   long z=c.getTimeInMillis();
			   m=s1.format(d1);
			   n=s1.format(d2);
			   if(y>z)
			   {
				r= m;   
			   }
			   else
			   {
				r=n;
			   }
		    }
		    catch(ParseException e)
		    {
		    	System.out.println("Invalid");
		    }
		}
		else
		{
			System.out.println("Invalid");
		}
		return r;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String a=sc.next();
	String b=sc.next();
	System.out.println(Date_Format.diffCalculation(a, b));
}
}
