import java.util.Scanner;

public class String_Encryption {
	static void encryption(String a)
	{
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<a.length();i++)
		{
			char d=a.charAt(i);
			if((i+1)%2!=0)
			{
				if(d=='z')
				{
					sb.append('a');
				}
				else if(d=='Z')
				{
					sb.append('A');
				}

				else
				{
					int c=(int)d;
					++c;
					sb.append((char)c);
				}

			}
			else
			{
				sb.append(d);
			}
		}

		System.out.println(sb);
	}
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();

		String_Encryption.encryption(a);


	}
}
