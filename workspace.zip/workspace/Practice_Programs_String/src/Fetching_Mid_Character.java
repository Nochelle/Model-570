import java.util.Scanner;
import java.util.StringTokenizer;

public class Fetching_Mid_Character {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		StringBuilder sb=new StringBuilder(s);
int a=s.length();
int b=a/2;
	System.out.println(sb.substring(b-1, b+1));
		
	}
}
