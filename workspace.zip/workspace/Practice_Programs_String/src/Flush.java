import java.util.Scanner;

public class Flush {
	static void flush(String s){
		int k=s.length();
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<k;i++)	
		{
			char c=s.charAt(i);

			if((!Character.isAlphabetic(c))&&c!=' ')
			{
				sb.append(c);

			}}	
		System.out.println(sb);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		Flush.flush(s);
	}
}
