import java.util.Scanner;

public class Password_Validation {
	static int k=0;
	static void validation(String s)
	{
		k=s.length();
		if(s.matches(".*[0-9]{1}.*")&&s.matches(".*[@#$]{1}.*")&&(k>=6&&k<=20))
		{
			System.out.println("Valid");
		}
		else
		{
			System.out.println("Invalid");
		}
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.next();
	Password_Validation.validation(s);
}
}
