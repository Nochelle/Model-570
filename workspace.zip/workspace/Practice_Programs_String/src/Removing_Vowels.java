import java.util.Scanner;

public class Removing_Vowels {
	static String Elimination(String s)
	{
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<s.length();i++)
		{
			char k=s.charAt(i);
			if((i+1)%2!=0)
			{
				sb.append(k);
			}
			
			else
			{
				if(k!='a'&&k!='e'&&k!='i'&&k!='o'&&k!='u'&&k!='A'&&k!='E'&&k!='I'&&k!='O'&&k!='U')
				{
					sb.append(k);
				}
			}
		}
		return sb.toString();
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	
	System.out.print(Removing_Vowels.Elimination(s));
	sc.close();
}
}
