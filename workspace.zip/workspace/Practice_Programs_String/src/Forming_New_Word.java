import java.util.Scanner;

public class Forming_New_Word {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String a=sc.next();
	int b=sc.nextInt();
	String c=a.substring(0, b)+a.substring(a.length()-b);
	System.out.println(c);
}
}
