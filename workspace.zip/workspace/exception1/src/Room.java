public class Room {
	int roomId; 
	int roomType;
	int roomNumber, roomCapacity;
	boolean roomAc, roomWifi, roomCabel, roomLaundry;
	public Room(int roomId, int roomType, int roomNumber, int roomCapacity,
			boolean roomAc, boolean roomWifi, boolean roomCabel,
			boolean roomLaundry) {
		super();
		this.roomId = roomId;
		this.roomType = roomType;
		this.roomNumber = roomNumber;
		this.roomCapacity = roomCapacity;
		this.roomAc = roomAc;
		this.roomWifi = roomWifi;
		this.roomCabel = roomCabel;
		this.roomLaundry = roomLaundry;
	}
	public void display(){
		System.out.println("Room Number :"+roomNumber);
		if(roomType==1){
		System.out.println("Room Type :Normal");}
		else if(roomType==2)
			System.out.println("Room Type :Delux");
		else if(roomType==3){
				System.out.println("Room Type :Super Delux");
		}
		System.out.println("Services Available:");
		if(roomAc){
		System.out.println("AC");
		}
		if(roomWifi){
			System.out.println("Wi-Fi");
		}
		if(roomCabel)
		System.out.println("Cable Connection");
		if(roomLaundry)
		System.out.println("Laundry");
	}
}  
