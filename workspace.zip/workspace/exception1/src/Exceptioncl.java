public class Exceptioncl extends Throwable{
public String getMessage(){
	return ("Invalid Room Number\nRe-enter Room Number");
}
}  