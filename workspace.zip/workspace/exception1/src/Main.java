import java.util.ArrayList;
import java.util.Scanner;


public class Main {
	static int roomType;
	static int roomNumber, roomCapacity;
	static boolean roomAc, roomWifi, roomCabel, roomLaundry;
	static int count=0;
	static int id;
	static String name;
	static String address;
	static String con;
	static ArrayList<Room> roomList=new ArrayList<Room>();
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter the Hotel details:");
	System.out.println("Enter the Hotel Name:");
    name=sc.next();
	System.out.println("Enter the Hotel ID:");
	id=sc.nextInt();
	System.out.println("Enter the Hotel Address");
	address=sc.next();
	do{
		System.out.println("Enter the Room Details:\nEnter the Room Id:");
	int roomid=sc.nextInt();
	do{
		System.out.println("Enter the Room Number:");
		roomNumber=sc.nextInt();
	}while(roomNum(roomNumber));
	System.out.println("Enter the Room Type:\n1)Normal\n2)Delux\n3)Super Delux");
	roomType=sc.nextInt();
	System.out.println("Enter the Room Capacity:(1/2/3/4)");
	roomCapacity=sc.nextInt();
	System.out.println("AC Service (true/false):");
	roomAc=sc.nextBoolean();
	System.out.println("Wi-Fi Service (true/false):");
	roomWifi=sc.nextBoolean();
	System.out.println("Cable Service (true/false):");
	roomCabel=sc.nextBoolean();
	System.out.println("Laundry Service (true/false):");
	roomLaundry=sc.nextBoolean();
	count++;
	roomList.add(new Room(roomid, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry));
	System.out.println("Do you want to add Another Room (yes/no):");
	con=sc.next();}while(con.equals("yes"));
	display();
}

public static boolean roomNum(int roomNumber){
	
	try{
	
	if(roomNumber<0){
		throw new Exceptioncl();
	}
	}catch(Exceptioncl ex){
		System.out.println(ex.getMessage());
		return true;
	}
	return false;
}
public static void display(){
	System.out.println("Thank you for booking !!\nThe rooms details:");
	System.out.println("Hotel Name:"+name+".");
	System.out.println("Hotel ID:"+id+".");
	System.out.println("Hotel Address:"+address+".");
	//System.out.println();
	//System.out.println("Room Details:");
	
	for(int i=0;i<count;i++){
		System.out.println();
		roomList.get(i).display();
	}
}

}  